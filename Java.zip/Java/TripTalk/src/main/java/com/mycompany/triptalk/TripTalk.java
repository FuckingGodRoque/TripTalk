
package com.mycompany.triptalk;

public class TripTalk {

    public static void main(String[] args) {
        new LoginFrame().setVisible(true);
    }
}
